;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tsc" "20251222.1418"
  "Core Tree-sitter APIs."
  '((emacs "27.1"))
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter"
  :commit "7eb54b045e52cd484d3b556f562d67b0d79c623e"
  :revdesc "7eb54b045e52"
  :keywords '("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :authors '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
             ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
