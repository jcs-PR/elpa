;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellsp" "20260114.516"
  "Elisp Language Server."
  '((emacs    "28.1")
    (lsp-mode "6.0.1")
    (log4e    "0.1.0")
    (dash     "2.14.1")
    (s        "1.12.0")
    (company  "0.8.12")
    (msgu     "0.1.0"))
  :url "https://github.com/elisp-lsp/ellsp"
  :commit "0a3bb0df5bfb26e689896753df0bca009971c087"
  :revdesc "0a3bb0df5bfb"
  :keywords '("convenience" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
