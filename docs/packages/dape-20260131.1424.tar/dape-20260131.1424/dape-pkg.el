;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260131.1424"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "836eec264ab35d11982f0563c536dac518fcf026"
  :revdesc "836eec264ab3"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
