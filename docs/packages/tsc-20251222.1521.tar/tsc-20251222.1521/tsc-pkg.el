;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tsc" "20251222.1521"
  "Core Tree-sitter APIs."
  '((emacs "27.1"))
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter"
  :commit "9eb069098b0c288a2d95a4e4c41072eadf2a16b7"
  :revdesc "9eb069098b0c"
  :keywords '("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :authors '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
             ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
